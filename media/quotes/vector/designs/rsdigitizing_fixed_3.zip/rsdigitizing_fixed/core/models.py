from django.db import models
from django.contrib.auth.models import AbstractUser


class User(AbstractUser):
    phone = models.CharField(max_length=15, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.get_full_name()} ({self.email})"


# ── SHARED CHOICES ─────────────────────────────────────────────────────────────

UNIT_CHOICES = [
    ('in', 'Inches'),
    ('cm', 'CM'),
    ('mm', 'MM'),
]

FORMAT_CHOICES = [
    ('DST', 'DST'), ('PES', 'PES'), ('EXP', 'EXP'),
    ('JEF', 'JEF'), ('VP3', 'VP3'), ('EMB', 'EMB'), ('XXX', 'XXX'), ('OTHER', 'Other'),
]

ORDER_STATUS_CHOICES = [
    ('new', 'New'),
    ('in_progress', 'In Progress'),
    ('completed', 'Completed'),
    ('delivered', 'Delivered'),
]

QUOTE_STATUS_CHOICES = [
    ('pending', 'Pending'),
    ('quoted', 'Quoted'),
    ('accepted', 'Accepted'),
    ('rejected', 'Rejected'),
]


# ═══════════════════════════════════════════════════════════════════════════════
#  PLACE NEW ORDER — 3 separate tables
# ═══════════════════════════════════════════════════════════════════════════════

class OrderDigitizing(models.Model):
    """PLACE NEW ORDER → Digitizing order"""
    user            = models.ForeignKey(User, on_delete=models.CASCADE, related_name='orders_digitizing')
    status          = models.CharField(max_length=20, choices=ORDER_STATUS_CHOICES, default='new')
    design_name     = models.CharField(max_length=200)
    po_number       = models.CharField(max_length=100, blank=True)
    width_mm        = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    height_mm       = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    size_unit       = models.CharField(max_length=5, choices=UNIT_CHOICES, default='in', blank=True)
    format          = models.CharField(max_length=10, choices=FORMAT_CHOICES, blank=True)
    fabric          = models.CharField(max_length=100, blank=True)
    colors          = models.PositiveIntegerField(null=True, blank=True)
    placement       = models.CharField(max_length=100, blank=True)
    instructions    = models.TextField(blank=True)
    urgent          = models.BooleanField(default=False)
    date_needed     = models.DateField(null=True, blank=True)
    design_file     = models.FileField(upload_to='orders/digitizing/designs/', null=True, blank=True)
    reference_file  = models.FileField(upload_to='orders/digitizing/references/', null=True, blank=True)
    price           = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    created_at      = models.DateTimeField(auto_now_add=True)
    updated_at      = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Order – Digitizing'
        verbose_name_plural = 'Orders – Digitizing'

    def size_display(self):
        if self.width_mm and self.height_mm:
            return f"{self.width_mm} × {self.height_mm} {self.size_unit or 'in'}"
        return "—"

    def __str__(self):
        return f"Digitizing Order #{self.pk} — {self.design_name}"


class OrderPatches(models.Model):
    """PLACE NEW ORDER → Patches order"""
    user            = models.ForeignKey(User, on_delete=models.CASCADE, related_name='orders_patches')
    status          = models.CharField(max_length=20, choices=ORDER_STATUS_CHOICES, default='new')
    design_name     = models.CharField(max_length=200)
    po_number       = models.CharField(max_length=100, blank=True)
    width_mm        = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    height_mm       = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    size_unit       = models.CharField(max_length=5, choices=UNIT_CHOICES, default='in', blank=True)
    colors          = models.PositiveIntegerField(null=True, blank=True)
    patch_type      = models.CharField(max_length=100, blank=True)
    backing         = models.CharField(max_length=100, blank=True)
    quantity        = models.PositiveIntegerField(null=True, blank=True)
    embroidery_pct  = models.CharField(max_length=10, blank=True)
    thread_color    = models.TextField(blank=True)
    instructions    = models.TextField(blank=True)
    urgent          = models.BooleanField(default=False)
    date_needed     = models.DateField(null=True, blank=True)
    design_file     = models.FileField(upload_to='orders/patches/designs/', null=True, blank=True)
    reference_file  = models.FileField(upload_to='orders/patches/references/', null=True, blank=True)
    price           = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    created_at      = models.DateTimeField(auto_now_add=True)
    updated_at      = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Order – Patches'
        verbose_name_plural = 'Orders – Patches'

    def size_display(self):
        if self.width_mm and self.height_mm:
            return f"{self.width_mm} × {self.height_mm} {self.size_unit or 'in'}"
        return "—"

    def __str__(self):
        return f"Patches Order #{self.pk} — {self.design_name}"


class OrderVector(models.Model):
    """PLACE NEW ORDER → Vector order"""
    user            = models.ForeignKey(User, on_delete=models.CASCADE, related_name='orders_vector')
    status          = models.CharField(max_length=20, choices=ORDER_STATUS_CHOICES, default='new')
    design_name     = models.CharField(max_length=200)
    po_number       = models.CharField(max_length=100, blank=True)
    vector_format   = models.CharField(max_length=50, blank=True)
    background      = models.CharField(max_length=50, blank=True)
    colors          = models.PositiveIntegerField(null=True, blank=True)
    instructions    = models.TextField(blank=True)
    urgent          = models.BooleanField(default=False)
    date_needed     = models.DateField(null=True, blank=True)
    design_file     = models.FileField(upload_to='orders/vector/designs/', null=True, blank=True)
    price           = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    created_at      = models.DateTimeField(auto_now_add=True)
    updated_at      = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Order – Vector'
        verbose_name_plural = 'Orders – Vector'

    def __str__(self):
        return f"Vector Order #{self.pk} — {self.design_name}"


# ═══════════════════════════════════════════════════════════════════════════════
#  ADD NEW QUOTE — 3 separate tables
# ═══════════════════════════════════════════════════════════════════════════════

class QuoteDigitizing(models.Model):
    """ADD NEW QUOTE → Digitizing order"""
    user            = models.ForeignKey(User, on_delete=models.CASCADE, related_name='quotes_digitizing')
    status          = models.CharField(max_length=20, choices=QUOTE_STATUS_CHOICES, default='pending')
    design_name     = models.CharField(max_length=200)
    po_number       = models.CharField(max_length=100, blank=True)
    width_mm        = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    height_mm       = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    size_unit       = models.CharField(max_length=5, choices=UNIT_CHOICES, default='in', blank=True)
    fabric          = models.CharField(max_length=100, blank=True)
    colors          = models.PositiveIntegerField(null=True, blank=True)
    placement       = models.CharField(max_length=100, blank=True)
    description     = models.TextField(blank=True)
    urgent          = models.BooleanField(default=False)
    date_needed     = models.DateField(null=True, blank=True)
    design_file     = models.FileField(upload_to='quotes/digitizing/designs/', null=True, blank=True)
    quoted_price    = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    admin_notes     = models.TextField(blank=True)
    created_at      = models.DateTimeField(auto_now_add=True)
    updated_at      = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Quote – Digitizing'
        verbose_name_plural = 'Quotes – Digitizing'

    def size_display(self):
        if self.width_mm and self.height_mm:
            return f"{self.width_mm} × {self.height_mm} {self.size_unit or 'in'}"
        return "—"

    def __str__(self):
        return f"Digitizing Quote #{self.pk} — {self.design_name}"


class QuotePatches(models.Model):
    """ADD NEW QUOTE → Patches order"""
    user            = models.ForeignKey(User, on_delete=models.CASCADE, related_name='quotes_patches')
    status          = models.CharField(max_length=20, choices=QUOTE_STATUS_CHOICES, default='pending')
    design_name     = models.CharField(max_length=200)
    po_number       = models.CharField(max_length=100, blank=True)
    width_mm        = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    height_mm       = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    size_unit       = models.CharField(max_length=5, choices=UNIT_CHOICES, default='in', blank=True)
    colors          = models.PositiveIntegerField(null=True, blank=True)
    patch_type      = models.CharField(max_length=100, blank=True)
    backing         = models.CharField(max_length=100, blank=True)
    quantity        = models.PositiveIntegerField(null=True, blank=True)
    embroidery_pct  = models.CharField(max_length=10, blank=True)
    thread_color    = models.TextField(blank=True)
    description     = models.TextField(blank=True)
    urgent          = models.BooleanField(default=False)
    date_needed     = models.DateField(null=True, blank=True)
    design_file     = models.FileField(upload_to='quotes/patches/designs/', null=True, blank=True)
    quoted_price    = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    admin_notes     = models.TextField(blank=True)
    created_at      = models.DateTimeField(auto_now_add=True)
    updated_at      = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Quote – Patches'
        verbose_name_plural = 'Quotes – Patches'

    def size_display(self):
        if self.width_mm and self.height_mm:
            return f"{self.width_mm} × {self.height_mm} {self.size_unit or 'in'}"
        return "—"

    def __str__(self):
        return f"Patches Quote #{self.pk} — {self.design_name}"


class QuoteVector(models.Model):
    """ADD NEW QUOTE → Vector order"""
    user            = models.ForeignKey(User, on_delete=models.CASCADE, related_name='quotes_vector')
    status          = models.CharField(max_length=20, choices=QUOTE_STATUS_CHOICES, default='pending')
    design_name     = models.CharField(max_length=200)
    po_number       = models.CharField(max_length=100, blank=True)
    vector_format   = models.CharField(max_length=50, blank=True)
    background      = models.CharField(max_length=50, blank=True)
    colors          = models.PositiveIntegerField(null=True, blank=True)
    description     = models.TextField(blank=True)
    urgent          = models.BooleanField(default=False)
    date_needed     = models.DateField(null=True, blank=True)
    design_file     = models.FileField(upload_to='quotes/vector/designs/', null=True, blank=True)
    quoted_price    = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    admin_notes     = models.TextField(blank=True)
    created_at      = models.DateTimeField(auto_now_add=True)
    updated_at      = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Quote – Vector'
        verbose_name_plural = 'Quotes – Vector'

    def __str__(self):
        return f"Vector Quote #{self.pk} — {self.design_name}"


# ═══════════════════════════════════════════════════════════════════════════════
#  LEGACY MODELS (kept for backward-compatibility / data migration)
# ═══════════════════════════════════════════════════════════════════════════════

class Order(models.Model):
    """Legacy single-table order — kept for existing data."""
    ORDER_TYPES = [
        ('digitizing', 'Embroidery Digitizing'),
        ('patches', 'Patches'),
        ('vector', 'Vector Art'),
    ]
    STATUS_CHOICES = ORDER_STATUS_CHOICES
    FORMAT_CHOICES = FORMAT_CHOICES
    UNIT_CHOICES   = UNIT_CHOICES

    user            = models.ForeignKey(User, on_delete=models.CASCADE, related_name='orders')
    order_type      = models.CharField(max_length=20, choices=ORDER_TYPES)
    status          = models.CharField(max_length=20, choices=STATUS_CHOICES, default='new')
    design_name     = models.CharField(max_length=200)
    po_number       = models.CharField(max_length=100, blank=True)
    width_mm        = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    height_mm       = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    size_unit       = models.CharField(max_length=5, choices=UNIT_CHOICES, default='in', blank=True)
    format          = models.CharField(max_length=10, choices=FORMAT_CHOICES, blank=True)
    fabric          = models.CharField(max_length=100, blank=True)
    colors          = models.PositiveIntegerField(null=True, blank=True)
    placement       = models.CharField(max_length=100, blank=True)
    instructions    = models.TextField(blank=True)
    urgent          = models.BooleanField(default=False)
    date_needed     = models.DateField(null=True, blank=True)
    design_file     = models.FileField(upload_to='orders/designs/', null=True, blank=True)
    reference_file  = models.FileField(upload_to='orders/references/', null=True, blank=True)
    patch_type      = models.CharField(max_length=100, blank=True)
    quantity        = models.PositiveIntegerField(null=True, blank=True)
    backing         = models.CharField(max_length=100, blank=True)
    thread_color    = models.TextField(blank=True)
    embroidery_pct  = models.CharField(max_length=10, blank=True)
    vector_format   = models.CharField(max_length=50, blank=True)
    background      = models.CharField(max_length=50, blank=True)
    price           = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    created_at      = models.DateTimeField(auto_now_add=True)
    updated_at      = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = '[Legacy] Order'
        verbose_name_plural = '[Legacy] Orders'

    def size_display(self):
        if self.width_mm and self.height_mm:
            return f"{self.width_mm} × {self.height_mm} {self.size_unit or 'in'}"
        return "—"

    def __str__(self):
        return f"[Legacy] Order #{self.pk} — {self.design_name}"


class Quote(models.Model):
    """Legacy single-table quote — kept for existing data."""
    QUOTE_TYPES    = [
        ('digitizing', 'Embroidery Digitizing'),
        ('patches', 'Patches'),
        ('vector', 'Vector Art'),
    ]
    STATUS_CHOICES = QUOTE_STATUS_CHOICES
    UNIT_CHOICES   = UNIT_CHOICES

    user            = models.ForeignKey(User, on_delete=models.CASCADE, related_name='quotes')
    quote_type      = models.CharField(max_length=20, choices=QUOTE_TYPES)
    status          = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    design_name     = models.CharField(max_length=200)
    po_number       = models.CharField(max_length=100, blank=True)
    width_mm        = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    height_mm       = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    size_unit       = models.CharField(max_length=5, choices=UNIT_CHOICES, default='in', blank=True)
    fabric          = models.CharField(max_length=100, blank=True)
    colors          = models.PositiveIntegerField(null=True, blank=True)
    placement       = models.CharField(max_length=100, blank=True)
    description     = models.TextField(blank=True)
    urgent          = models.BooleanField(default=False)
    date_needed     = models.DateField(null=True, blank=True)
    design_file     = models.FileField(upload_to='quotes/designs/', null=True, blank=True)
    patch_type      = models.CharField(max_length=100, blank=True)
    quantity        = models.PositiveIntegerField(null=True, blank=True)
    backing         = models.CharField(max_length=100, blank=True)
    thread_color    = models.TextField(blank=True)
    embroidery_pct  = models.CharField(max_length=10, blank=True)
    vector_format   = models.CharField(max_length=50, blank=True)
    background      = models.CharField(max_length=50, blank=True)
    quoted_price    = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    admin_notes     = models.TextField(blank=True)
    created_at      = models.DateTimeField(auto_now_add=True)
    updated_at      = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = '[Legacy] Quote'
        verbose_name_plural = '[Legacy] Quotes'

    def size_display(self):
        if self.width_mm and self.height_mm:
            return f"{self.width_mm} × {self.height_mm} {self.size_unit or 'in'}"
        return "—"

    def __str__(self):
        return f"[Legacy] Quote #{self.pk} — {self.design_name}"


class Invoice(models.Model):
    STATUS_CHOICES = [
        ('uninvoiced', 'Uninvoiced'),
        ('unpaid', 'Unpaid'),
        ('paid', 'Paid'),
    ]

    user           = models.ForeignKey(User, on_delete=models.CASCADE, related_name='invoices')
    order          = models.ForeignKey(Order, on_delete=models.SET_NULL, null=True, blank=True)
    invoice_number = models.CharField(max_length=50, unique=True)
    status         = models.CharField(max_length=20, choices=STATUS_CHOICES, default='uninvoiced')
    amount         = models.DecimalField(max_digits=10, decimal_places=2)
    description    = models.TextField(blank=True)
    due_date       = models.DateField(null=True, blank=True)
    paid_at        = models.DateTimeField(null=True, blank=True)
    created_at     = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Invoice {self.invoice_number} — Rs.{self.amount}"


class ContactMessage(models.Model):
    SERVICE_CHOICES = [
        ('Logo Digitizing', 'Logo Digitizing'),
        ('3D Puff Embroidery', '3D Puff Embroidery'),
        ('Cap Digitizing', 'Cap Digitizing'),
        ('Screen Printing', 'Screen Printing'),
        ('Vinyl Cutting / HTV', 'Vinyl Cutting / HTV'),
        ('Digital Printing & Stickers', 'Digital Printing & Stickers'),
        ('Corporate Uniforms', 'Corporate Uniforms'),
        ('Sports Uniforms', 'Sports Uniforms'),
        ('Custom Design Work', 'Custom Design Work'),
        ('Other', 'Other'),
    ]

    first_name = models.CharField(max_length=100)
    last_name  = models.CharField(max_length=100)
    email      = models.EmailField()
    phone      = models.CharField(max_length=15)
    service    = models.CharField(max_length=100, choices=SERVICE_CHOICES)
    message    = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.first_name} {self.last_name} — {self.service} ({self.email})"
